# quantum6g/__init__.py
from .quantum6g import Quantum6G
