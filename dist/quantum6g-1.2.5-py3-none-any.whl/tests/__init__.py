# tests/__init__.py
from .test import TestQuantum6G